# Godot Welcome Message Asset

This is a simple Godot asset that shows how to:
- Take user input (name) from a LineEdit
- Display a personalized welcome message
- Handle empty input gracefully

## Node Structure


Node2D (root) 
  ├─ CanvasLayer │    ├─ LineEdit   (User name input) │    ├─ Button     (Confirm button) │    └─ Label      (Output message)
## How to Use
1. Import the project into Godot 4.5
2. Open the scene and run it.
3. Enter your name, press the button, and see the welcome message!

## Example
If the user enters:

Arshia

The output will be:

Arshia, welcome 🎉

## License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
